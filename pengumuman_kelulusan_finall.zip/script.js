function cekKelulusan() {
  const nisn = document.getElementById('nisn').value;
  const hasilDiv = document.getElementById('hasil');
  const dataKelulusan = {
    '1234567890': '"SELAMAT ANDA DI NYATAKAN LULUS DI SMP Negeri 1 Pronojiwo" Tahun Pelajaran 2024/2025. Terus melangkah gapailah cita-cita setinggi langit, hari ini bukan akhir tapi petualanganmu yang lebih besar',
    '0987654321': 'Maaf, Anda BELUM LULUS.'
  };

  if (dataKelulusan[nisn]) {
    document.querySelector('.main-content').style.display = 'none';
    const resultText = document.getElementById('result-text');
    resultText.innerText = dataKelulusan[nisn];
    resultText.classList.remove('result-text-animate'); // Reset animasi
    void resultText.offsetWidth; // Trigger reflow
    resultText.classList.add('result-text-animate'); // Aktifkan animasi

    resultText.style.color = dataKelulusan[nisn].includes('LULUS') ? 'green' : 'red';
    document.querySelector('.result-content').style.display = 'flex';
  } else {
    hasilDiv.innerText = 'NISN tidak ditemukan.';
    hasilDiv.style.color = 'orange';
  }
}


  if (dataKelulusan[nisn]) {
    document.querySelector('.main-content').style.display = 'none';
    document.querySelector('.result-content').style.display = 'flex';
    document.getElementById('result-text').innerText = dataKelulusan[nisn];
    document.getElementById('result-text').style.color = dataKelulusan[nisn].includes('LULUS') ? 'blue' : 'red';
  } else {
    hasilDiv.innerText = 'NISN tidak ditemukan.';
    hasilDiv.style.color = 'black';
  }

